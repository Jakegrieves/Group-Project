//The NFT list page is the main page, 
//The will contains 2 columns with different type of NFT(fixed price or acution)
import Navbar from "./Navbar";
import NFTTile from "./NFTTile";
import JJAXJSON from "../JJAX.json";
import axios from "axios";
import { useState } from "react";
import { GetIpfsUrlFromPinata } from "../utils";

export default function Marketplace() {

const [data, updateData] = useState('');
async function getAllNFTs() {
    const ethers = require("ethers");
    //After adding your Hardhat network to your metamask, this code will get providers and signers
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    //Pull the deployed contract instance
    let contract = new ethers.Contract(JJAXJSON.address, JJAXJSON.abi, signer)
    //create an NFT Token
 
}

return }
    