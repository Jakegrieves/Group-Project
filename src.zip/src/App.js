import './App.css';
import Navbar from './components/Navbar.js';
import NFTList  from './components/NFTlistPage.js';
import UploadAuction from './components/UploadAuction.js';
import UploadList from './components/UploadList.js';

import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";

function App() {
  return (
    <div>
      <Navbar></Navbar>
    
    <div className="container">
        <Routes>
          {/*<Route path="/" element={<NFTList />}/>*/}
          <Route path="/UploadList" element={<UploadList />}/>        
          {/*<Route path="/UploadAuction" element={<UploadAuction />}/>*/}     
        </Routes>
    </div>
    </div>
  );
}

export default App;